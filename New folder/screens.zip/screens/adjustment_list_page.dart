import 'package:flutter/material.dart';
import '../services/adjustment_service.dart';
import 'choice_page.dart';
import '../utils/constants.dart';

class AdjustmentsListPage extends StatefulWidget {
  const AdjustmentsListPage({Key? key}) : super(key: key);

  @override
  State<AdjustmentsListPage> createState() => _AdjustmentsListPageState();
}

class _AdjustmentsListPageState extends State<AdjustmentsListPage> {
  List adjustments = [];
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    fetchAdjustments();
  }

  void fetchAdjustments() async {
    try {
      final data = await AdjustmentService.getAdjustments();
      setState(() {
        adjustments = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = e.toString();
        isLoading = false;
      });
    }
  }

  String formatDate(String? date) {
    if (date == null) return "";
    try {
      final parsedDate = DateTime.parse(date);
      return "${parsedDate.day}/${parsedDate.month}";
    } catch (e) {
      return date;
    }
  }

  Color getStatusColor(String? state) {
    switch (state) {
      case 'draft': return AppColors.warningColor;
      case 'in_progress': return AppColors.successColor;
      case 'done': return AppColors.secondaryColor;
      case 'cancel': return AppColors.errorColor;
      default: return Colors.grey;
    }
  }

  String getStatusText(String? state) {
    switch (state) {
      case 'draft': return 'Brouillon';
      case 'in_progress': return 'en cours';
      case 'done': return 'fait';
      case 'cancel': return 'Annulé';
      default: return state ?? 'Inconnu';
    }
  }

  // ✅ Shows the full adjustment info (untruncated name, status, date) in a
  // popup before navigating, since the card itself is too small to show
  // long adjustment names in full.
  void _showAdjustmentDetails(dynamic adj) {
    final name = adj["name"] ?? "Sans nom";
    final state = adj["state"];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.inventory_2, color: getStatusColor(state), size: 20),
            const SizedBox(width: 8),
            const Expanded(
              child: Text("Détails de l'ajustement", style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              name,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    color: getStatusColor(state).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    getStatusText(state),
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: getStatusColor(state),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.calendar_today, size: 12, color: Colors.grey[500]),
                const SizedBox(width: 4),
                Text(
                  formatDate(adj["date"]),
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Fermer"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context); // close the popup
              Navigator.pushNamed(
                context,
                '/choice-page',
                arguments: {'id': adj["id"], 'managerId': adj["manager_id"]},
              );
            },
            child: const Text("Continuer"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        title: const Text("Ajustements", style: TextStyle(fontSize: 16)),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, size: 22),
          onPressed: () => Navigator.pushReplacementNamed(context, '/adjustment-entry'),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Image.asset(
              "assets/images/image266622.png",
              height: 28,
              errorBuilder: (context, error, stackTrace) =>
              const Icon(Icons.inventory, color: Colors.white, size: 22),
            ),
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage != null
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 40, color: AppColors.errorColor),
            const SizedBox(height: 8),
            Text("Error: $errorMessage", style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  isLoading = true;
                  errorMessage = null;
                  fetchAdjustments();
                });
              },
              child: const Text("Réessayer", style: TextStyle(fontSize: 12)),
            ),
          ],
        ),
      )
          : adjustments.isEmpty
          ? const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inventory, size: 40, color: Colors.grey),
            SizedBox(height: 8),
            Text("Aucun ajustement trouvé", style: TextStyle(fontSize: 12)),
          ],
        ),
      )
          : SingleChildScrollView(
        padding: const EdgeInsets.all(6.0),
        child: Wrap(
          spacing: 6,
          runSpacing: 6,
          children: List.generate(adjustments.length, (index) {
            final adj = adjustments[index];
            final cardWidth = (MediaQuery.of(context).size.width - 18) / 2;

            return GestureDetector(
              onTap: () => _showAdjustmentDetails(adj),
              child: SizedBox(
                width: cardWidth,
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.surfaceColor,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderColor),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primaryColor.withOpacity(0.05),
                        spreadRadius: 1,
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min, // ← shrink to content
                    children: [
                      // Status bar
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                        decoration: BoxDecoration(
                          color: getStatusColor(adj["state"]).withOpacity(0.15),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              getStatusText(adj["state"]),
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: getStatusColor(adj["state"]),
                              ),
                            ),
                            Icon(Icons.chevron_right, size: 14, color: Colors.grey[400]),
                          ],
                        ),
                      ),
                      // Content
                      Padding(
                        padding: const EdgeInsets.all(8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              adj["name"] ?? "Sans nom",
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Icon(Icons.calendar_today, size: 10, color: Colors.grey[500]),
                                const SizedBox(width: 2),
                                Text(
                                  formatDate(adj["date"]),
                                  style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                              decoration: BoxDecoration(
                                color: AppColors.secondaryColor.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    "Voir",
                                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.secondaryColor),
                                  ),
                                  SizedBox(width: 2),
                                  Icon(Icons.arrow_forward, size: 10, color: AppColors.secondaryColor),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}