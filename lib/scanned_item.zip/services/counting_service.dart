import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api_config.dart';
import '../models/scanned_item.dart';
import 'local_storage_service.dart';

class CountingService {
  // ✅ OFFLINE-FIRST: Check cache, then API
  static Future<Map<String, dynamic>?> lookupProduct(String barcode) async {
    try {
      // 1️⃣ Check local cache FIRST (instant, no internet needed)
      final cachedProduct = await LocalStorageService.getCachedProduct(barcode);
      if (cachedProduct != null) {
        print("✅ Product found in OFFLINE cache: ${cachedProduct['name']}");
        return cachedProduct;
      }

      // 2️⃣ If not in cache, try API (requires internet)
      print("🌐 Looking up product ONLINE: $barcode");
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/counting/lookup-product'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({'barcode': barcode}),
      );

      print("Product lookup status: ${response.statusCode}");
      print("Product lookup body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true && data['product'] != null) {
          final product = data['product'];
          // ✅ Cache the product for future offline use
          await LocalStorageService.cacheProduct(barcode, product);
          print("✅ Product cached for offline use: ${product['name']}");
          return product;
        }
      }
      return null;
    } catch (e) {
      print("Product lookup error: $e");
      // ✅ If offline, return null (product not in cache)
      return null;
    }
  }

  // Get counting sheet state
  static Future<Map<String, dynamic>?> getSheetState(int sheetId) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/counting/sheet-state/$sheetId'),
      );

      print("Sheet state status: ${response.statusCode}");
      print("Sheet state body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['sheet'];
      }
      return null;
    } catch (e) {
      print("Get sheet state error: $e");
      return null;
    }
  }

  // Start a counting sheet
  static Future<bool> startSheet(int sheetId) async {
    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/counting/start-sheet'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({'sheet_id': sheetId}),
      );

      print("Start sheet status: ${response.statusCode}");
      print("Start sheet body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['success'] == true;
      }
      return false;
    } catch (e) {
      print("Start sheet error: $e");
      return false;
    }
  }

  // Validate a counting sheet (finish counting)
  static Future<bool> validateSheet(int sheetId) async {
    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/counting/validate-sheet'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({'sheet_id': sheetId}),
      );

      print("Validate sheet status: ${response.statusCode}");
      print("Validate sheet body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['success'] == true;
      }
      return false;
    } catch (e) {
      print("Validate sheet error: $e");
      return false;
    }
  }

  // Submit scanned items to backend
  static Future<bool> submitScannedItems({
    required int countingSheetId,
    required int adjustmentId,
    required List<ScannedItem> items,
  }) async {
    try {
      if (items.isEmpty) {
        print("No items to submit");
        return false;
      }

      print("Submitting ${items.length} items");

      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/counting/submit-scans'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          'counting_sheet_id': countingSheetId,
          'adjustment_id': adjustmentId,
          'items': items.map((e) => e.toJson()).toList(),
        }),
      );

      print("Submit status: ${response.statusCode}");
      print("Submit body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['success'] == true;
      } else {
        print("Server returned error status: ${response.statusCode}");
        return false;
      }
    } catch (e) {
      print("Submit error: $e");
      return false;
    }
  }

  // ✅ Get number of cached products
  static Future<int> getCachedProductsCount() async {
    return await LocalStorageService.getCachedProductsCount();
  }
}