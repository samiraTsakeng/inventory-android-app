import 'dart:convert';
import 'package:http/http.dart' as http;

class AdjustmentService {
  static Future<List> getAdjustments() async {
    final response = await http.get(
      Uri.parse("http://192.168.1.109:3000/adjustments"),
    );

    final data = jsonDecode(response.body);

    return data;
  }
}