const bcrypt = require('bcryptjs');
const pool = require('../config/db');

async function createAdmin() {
    const username = 'admin';
    const password = 'admin';
    const hash = await bcrypt.hash(password, 10);

    const result = await pool.query(
     `INSERT INTO users (username, password_hash, role)
     VALUES ($1, $2, 'admin')
     ON CONFLICT (username) DO UPDATE SET password_hash = $2
     RETURNING id, username`,
    [username, hash]
  );
  console.log('User created:', result.rows[0]);
  process.exit(0);
}

createAdmin().catch(err => {
    console.error(err);
    process.exit(1);
})