const xmlrpc = require('xmlrpc');
const config = require('../config/odoo');

console.log('testing erp odoo connection...');
console.log('URL:', config.url);
console.log('Database:', config.db);
console.log('Username:', config.username);

//step1: test basic server reachability
const commonClient = xmlrpc.createClient({
    url: `${config.url}/xmlrpc/2/common`
});

//Authenticate
commonClient.methodCall('authenticate', [
    config.db,
    config.username,
    config.password,
    {}
], (err, uid) => {
    if (err) {
        console.error('CONNECTION TO ODOO FAILED:', err.message);
        console.log('\nPossible causes are:');
        console.log('-odoo is not running (check http://localhost:8068)');
        console.log('-wrong db name');
        console.log('-wrong username or password');
        process.exit(1);
    }

    if (!uid) {
        console.error('AUTH FAILED: uid is null -wrong username or password');
        process.exit(1);
    }

    console.log('\nOdoo connection SUCCESSSS🥳🥳🥳💖💖');
    console.log('Authenticated as user ID:', uid);

    // Check available product models
    const objectClient = xmlrpc.createClient({
        url: `${config.url}/xmlrpc/2/object`
    });

    objectClient.methodCall('execute_kw', [
        config.db,
        uid,
        config.password,
        'ir.model',
        'search_read',
        [[['model', 'ilike', 'product']]],
        { fields: ['model', 'name'], limit: 10 }
    ], (err2, models) => {
        if (err2) {
            console.error('Model fetch failed:', err2.message);
        } else {
            console.log('\nAvailable product-related models:');
            models.forEach(m => {
                console.log(` - ${m.model}: ${m.name}`);
            });
        }

        // Now fetch products with CORRECT domain syntax
        console.log('\nFetching products from product.product...');
        
        objectClient.methodCall('execute_kw', [
            config.db,
            uid,
            config.password,
            'product.product',
            'search_read',
            [[]],  // ✅ Correct: empty array for domain (get all records)
            {
                fields: ['id', 'name', 'default_code', 'barcode', 'qty_available'],
                limit: 5
            }
        ], (err3, products) => {
            if (err3) {
                console.error('Product fetch failed:', err3.message);
                console.log('\nTrying with product.template instead...');
                
                // Try with product.template
                objectClient.methodCall('execute_kw', [
                    config.db,
                    uid,
                    config.password,
                    'product.template',
                    'search_read',
                    [[]],  // ✅ Correct domain
                    {
                        fields: ['id', 'name', 'default_code', 'barcode'],
                        limit: 5
                    }
                ], (err4, templates) => {
                    if (err4) {
                        console.error('Product template fetch also failed:', err4.message);
                        console.log('\nThis might be because:');
                        console.log('1. No products exist in the database yet');
                        console.log('2. The user lacks read permissions');
                        console.log('\nTry creating a test product in Odoo:');
                        console.log('- Go to http://localhost:8068');
                        console.log('- Login as admin');
                        console.log('- Go to Sales → Products → Products');
                        console.log('- Click "Create" and add a product');
                        process.exit(1);
                    } else {
                        displayProducts(templates);
                    }
                });
            } else {
                displayProducts(products);
            }
        });
    });
});

function displayProducts(products) {
    if (!products || products.length === 0) {
        console.log('\n⚠️  No products found in the database.');
        console.log('\nThis is normal if you haven\'t created any products yet.');
        console.log('\nTo create a test product:');
        console.log('1. Go to http://localhost:8068');
        console.log('2. Login as admin');
        console.log('3. Go to Inventory → Products → Products (or Sales → Products)');
        console.log('4. Click "Create" and fill in:');
        console.log('   - Product Name: "Test Product"');
        console.log('   - Internal Reference: "TEST001"');
        console.log('5. Click "Save"');
        console.log('\nAfter creating a product, run this script again.');
        process.exit(0);
    }
    
    console.log('\n✅ Inventory module is accessible!');
    console.log(`Found ${products.length} products:\n`);
    
    products.forEach(p => {
        console.log(`📦 Product ID: ${p.id}`);
        console.log(`   Name: ${p.name}`);
        if (p.default_code) console.log(`   SKU/Code: ${p.default_code}`);
        if (p.barcode) console.log(`   Barcode: ${p.barcode}`);
        if (p.qty_available !== undefined) console.log(`   Stock: ${p.qty_available}`);
        console.log('');
    });
    
    console.log('✅ All tests passed! Odoo connection is working properly.');
    process.exit(0);
}
        /*console.log('\nInventory module accessible');
        console.log(`Found ${products.length} sample products:\n`);
        products.forEach(p => {
            console.log(` -[${p.id}] ${p.name}`);
            console.log(`   Barcode: ${p.barcode || 'none'}`);
            console.log(`   Stock: ${p.qty_available}`);
        });
        console.log('\nAll tests passed. Odoo is readyyyyy');
        process.exit(0);
    } );

});*/