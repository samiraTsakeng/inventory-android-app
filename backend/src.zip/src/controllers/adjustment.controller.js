const OdooService = require("../services/odooServices");
const AuthController = require("./authController");

class AdjustmentController {
  static async getAdjustments(req, res) {
    try {
      const { host } = AuthController.sessionData;

      const adjustments = await OdooService.fetchAdjustments(host);

      // 🔥 SORT
      adjustments.sort((a, b) => {
        if (a.state === "en cours") return -1;
        if (b.state === "en cours") return 1;
        return 0;
      });

      res.json(adjustments);

    } catch (error) {
      console.log("ADJUSTMENT ERROR:", error.message);

      res.status(500).json({
        success: false,
        message: error.message
      });
    }
  }
}

module.exports = AdjustmentController;