const pool = require('../config/db');
const odooService = require('../services/odooServices');
const crypto = require('crypto');

// Generate a short unique join code like "INV-4F2A"
function generateBatchCode() {
  return 'INV-' + crypto.randomBytes(2).toString('hex').toUpperCase();
}

// POST /api/batch/create
exports.createBatch = async (req, res) => {
  try {
    const userId = req.user.id;
    const batchCode = generateBatchCode();

    const result = await pool.query(
      `INSERT INTO batches (batch_code, created_by, status)
       VALUES ($1, $2, 'pending') RETURNING *`,
      [batchCode, userId]
    );
    const batch = result.rows[0];

    // Creator also joins as owner in batch_users
    await pool.query(
      `INSERT INTO batch_users (batch_id, user_id, role)
       VALUES ($1, $2, 'owner')`,
      [batch.id, userId]
    );

    res.status(201).json({ success: true, batch });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/batch/join
exports.joinBatch = async (req, res) => {
  try {
    const { batchCode } = req.body;
    const userId = req.user.id;

    const batchResult = await pool.query(
      `SELECT * FROM batches WHERE batch_code = $1 AND status = 'pending'`,
      [batchCode]
    );
    if (batchResult.rows.length === 0) {
      return res.status(404).json({ message: 'Batch not found or already sent' });
    }
    const batch = batchResult.rows[0];

    // Check if already in batch
    const existing = await pool.query(
      `SELECT id FROM batch_users WHERE batch_id = $1 AND user_id = $2`,
      [batch.id, userId]
    );
    if (existing.rows.length > 0) {
      return res.json({ success: true, message: 'Already in batch', batch });
    }

    await pool.query(
      `INSERT INTO batch_users (batch_id, user_id, role) VALUES ($1, $2, 'member')`,
      [batch.id, userId]
    );

    res.json({ success: true, message: 'Successfully joined batch', batch });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/batch/:batchId/scan
exports.scanItem = async (req, res) => {
  try {
    const { batchId } = req.params;
    const { barcode } = req.body;
    const userId = req.user.id;

    // Confirm user belongs to this batch
    const memberCheck = await pool.query(
      `SELECT id FROM batch_users WHERE batch_id = $1 AND user_id = $2`,
      [batchId, userId]
    );
    if (memberCheck.rows.length === 0) {
      return res.status(403).json({ message: 'Not a member of this batch' });
    }

    // Validate barcode against Odoo
    const product = await odooService.getProductByBarcode(barcode);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found in ERP' });
    }

    // Insert or increment quantity
    const result = await pool.query(
      `INSERT INTO items (batch_id, barcode, product_name, odoo_product_id, quantity, scanned_by)
       VALUES ($1, $2, $3, $4, 1, $5)
       ON CONFLICT (batch_id, barcode)
       DO UPDATE SET quantity = items.quantity + 1
       RETURNING *`,
      [batchId, barcode, product.name, product.id, userId]
    );

    res.json({ success: true, item: result.rows[0], product });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/batch/:batchId/items
exports.getBatchItems = async (req, res) => {
  try {
    const { batchId } = req.params;
    const result = await pool.query(
      `SELECT i.*, u.username as scanned_by_name
       FROM items i
       LEFT JOIN users u ON i.scanned_by = u.id
       WHERE i.batch_id = $1
       ORDER BY i.scanned_at ASC`,
      [batchId]
    );
    res.json({ success: true, items: result.rows });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// PUT /api/batch/:batchId/item/:itemId
exports.updateItem = async (req, res) => {
  try {
    const { batchId, itemId } = req.params;
    const { quantity } = req.body;

    if (quantity < 1) {
      return res.status(400).json({ message: 'Quantity must be at least 1' });
    }

    const result = await pool.query(
      `UPDATE items SET quantity = $1
       WHERE id = $2 AND batch_id = $3 RETURNING *`,
      [quantity, itemId, batchId]
    );
    res.json({ success: true, item: result.rows[0] });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE /api/batch/:batchId/item/:itemId
exports.deleteItem = async (req, res) => {
  try {
    const { batchId, itemId } = req.params;
    await pool.query(
      `DELETE FROM items WHERE id = $1 AND batch_id = $2`,
      [itemId, batchId]
    );
    res.json({ success: true, message: 'Item deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/batch/:batchId/submit
exports.submitBatch = async (req, res) => {
  const { batchId } = req.params;
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    await client.query(
      `UPDATE batches SET status = 'sending' WHERE id = $1`,
      [batchId]
    );

    const itemsResult = await client.query(
      `SELECT * FROM items WHERE batch_id = $1`,
      [batchId]
    );
    const items = itemsResult.rows;

    if (items.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ message: 'Batch is empty' });
    }

    // Send to Odoo
    const odooResult = await odooService.sendInventoryBatch(items);

    await client.query(
      `UPDATE batches SET status = 'sent', sent_at = NOW() WHERE id = $1`,
      [batchId]
    );

    await client.query(
      `INSERT INTO sync_logs (batch_id, status) VALUES ($1, 'sent')`,
      [batchId]
    );

    await client.query('COMMIT');

    res.json({ success: true, odooResult });
  } catch (err) {
    await client.query('ROLLBACK');

    await pool.query(
      `UPDATE batches SET status = 'failed' WHERE id = $1`,
      [batchId]
    );
    await pool.query(
      `INSERT INTO sync_logs (batch_id, status, error_message) VALUES ($1, 'failed', $2)`,
      [batchId, err.message]
    );

    res.status(500).json({ success: false, message: err.message });
  } finally {
    client.release();
  }
};

// GET /api/batch/archive — batches not expired
exports.getArchive = async (req, res) => {
  try {
    const userId = req.user.id;
    const result = await pool.query(
      `SELECT b.* FROM batches b
       JOIN batch_users bu ON b.id = bu.batch_id
       WHERE bu.user_id = $1
         AND b.status = 'sent'
         AND b.expires_at > NOW()
       ORDER BY b.sent_at DESC`,
      [userId]
    );
    res.json({ success: true, batches: result.rows });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/*const pool = require('../config/db');

function generateBatchCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

exports.createBatch = async (req, res) => {
  const userId = req.user.userId;

  try {
    const batchCode = generateBatchCode();

    const batchResult = await pool.query(
      `INSERT INTO batches (batch_code, status)
       VALUES ($1, 'pending')
       RETURNING *`,
      [batchCode]
    );

    const batch = batchResult.rows[0];

    // link user to batch
    await pool.query(
      `INSERT INTO batch_users (batch_id, user_id, role)
       VALUES ($1, $2, 'owner')`,
      [batch.id, userId]
    );

    res.json({
      message: 'Batch created',
      batch
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
*/
