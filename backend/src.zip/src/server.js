const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// ✅ SIMPLE TEST ROUTE
app.get("/", (req, res) => {
  res.send("Server is alive");
});

// ✅ FORCE SERVER TO STAY ALIVE
const server = app.listen(3000, () => {
  console.log("Server running on port 3000");
});

// 🔥 VERY IMPORTANT DEBUG
server.on("close", () => {
  console.log("⚠️ SERVER CLOSED");
});