//const fetch = require("node-fetch");

class OdooService {
  static sessionCookie = "";

  static async authenticate(host, db, email, password) {
    const response = await fetch(`${host}/web/session/authenticate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        method: "call",
        params: {
          db: db,
          login: email,
          password: password
        }
      })
    });

    const data = await response.json();

    console.log("Odoo login response:", data);

    if (!data.result) {
      throw new Error("Authentication failed");
    }

    // ✅ FIXED COOKIE HANDLING
    const cookies = response.headers.get('set-cookie');

    if (cookies) {
      this.sessionCookie = cookies;
    } else {
      throw new Error("No session cookie received");
    }

    return data.result;
  }

  static async fetchAdjustments(host) {
    const response = await fetch(`${host}/web/dataset/search_read`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Cookie": this.sessionCookie
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        method: "call",
        params: {
          model: "wise_inventory.adjustment",
          fields: [
            "name",
            "state",
            "date_comptage",
            "emplacement_id",
            "zone_id",
            "responsable_id",
            "equipe_id"
          ],
          domain: []
        }
      })
    });

    const data = await response.json();

    console.log("Adjustments response:", data);

    if (!data.result) {
      throw new Error("Failed to fetch adjustments");
    }

    return data.result.records;
  }
}

module.exports = OdooService;