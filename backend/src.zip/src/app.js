require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/batch', require('./routes/batchRoutes'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

/*const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/authRoutes');
const batchRoutes = require('./routes/batchRoutes');

const app = express();

app.use(cors());
app.use(express.json());
app.use('/api/auth', authRoutes);
app.use('/api/batches', batchRoutes);

// test route
app.get('/', (req, res) => {
  res.send('API is running...');
});

module.exports = app;
*/